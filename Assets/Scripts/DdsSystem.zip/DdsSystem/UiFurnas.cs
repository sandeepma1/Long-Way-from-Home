﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class UiFurnas : DragDropBase
{
    [SerializeField] private int slotCount = 20;

    private void Start()
    {
        CreateUiSlots(slotCount, this.transform);
        InstantiateUiSlotItem(uiSlots[0].transform);
    }

    //protected override void OnSlotDrop(UiSlot uiSlot, UiSlotItem uiSlotItem)
    //{
    //    base.OnSlotDrop(uiSlot, uiSlotItem);
    //}
}
