﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class UiSlot : MonoBehaviour, IDropHandler
{
    public Action<UiSlot, UiSlotItem> OnSlotDrop;
    public int id;

    public void OnDrop(PointerEventData eventData)
    {
        OnSlotDrop?.Invoke(this, eventData.pointerDrag.GetComponent<UiSlotItem>());
    }
}