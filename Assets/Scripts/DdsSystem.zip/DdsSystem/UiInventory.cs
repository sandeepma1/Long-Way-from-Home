﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UiInventory : DragDropBase
{
    [SerializeField] private int slotCount = 5;

    private void Start()
    {
        CreateUiSlots(slotCount, this.transform);
        InstantiateUiSlotItem(uiSlots[1].transform);
        //UiSlotItem uiSlotItem = Instantiate(uiSlotItemPrefab, uiSlots[0].transform);
    }

    //protected override void OnSlotDrop(UiSlot uiSlot, UiSlotItem uiSlotItem)
    //{
    //    base.OnSlotDrop(uiSlot, uiSlotItem);
    //}
}
