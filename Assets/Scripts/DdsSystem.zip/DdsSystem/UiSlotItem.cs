﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class UiSlotItem : MonoBehaviour, IDragHandler, IBeginDragHandler, IEndDragHandler
{
    public Action<UiSlotItem> OnSlotItemBeginDrag;
    public Action<UiSlotItem> OnSlotItemEndDrag;
    public Image image;
    public Iteo iteo;

    public void OnDrag(PointerEventData eventData)
    {
        transform.position = eventData.position;
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        OnSlotItemBeginDrag?.Invoke(this);
        image.raycastTarget = false;
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        bool onSlot = false;
        List<GameObject> gameObjects = eventData.hovered;
        for (int i = 0; i < gameObjects.Count; i++)
        {
            //print(gameObjects[i].name);
            if (gameObjects[i].GetComponent<UiSlot>())
            {
                onSlot = true;
            }
            if (gameObjects[i].GetComponent<DragDropBase>())
            {
                print(gameObjects[i].name);
                //this.OnSlotItemEndDrag += gameObjects[i].GetComponent<DragDropBase>().OnSlotItemEndDrag;
            }
        }
        if (!onSlot)
        {
            print("not on slot");
            OnSlotItemEndDrag?.Invoke(this);
        }
        transform.localPosition = Vector3.zero;
        image.raycastTarget = true;
    }
}
