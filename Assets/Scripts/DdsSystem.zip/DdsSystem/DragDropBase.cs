﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DragDropBase : MonoBehaviour
{
    [SerializeField] protected UiSlot uiSlotPrefab;
    [SerializeField] protected UiSlotItem uiSlotItemPrefab;
    protected UiSlot[] uiSlots;
    public List<UiSlotItem> uiSlotItems;

    protected virtual void OnSlotDrop(UiSlot uiSlot, UiSlotItem uiSlotItem)
    {
        if (uiSlot.transform.childCount == 0)
        {
            uiSlotItem.transform.SetParent(uiSlot.transform);
            AddSlotItems(uiSlotItem);
        }
    }

    protected virtual void CreateUiSlots(int slotCount, Transform parent)
    {
        uiSlots = new UiSlot[slotCount];
        for (int i = 0; i < slotCount; i++)
        {
            uiSlots[i] = InstantiateUiSlot(i, parent);
            uiSlots[i].OnSlotDrop += OnSlotDrop;
        }
    }

    protected virtual UiSlot InstantiateUiSlot(int id, Transform parent)
    {
        UiSlot uiSlot = Instantiate(uiSlotPrefab, parent);
        uiSlot.id = id;
        return uiSlot;
    }


    protected virtual UiSlotItem InstantiateUiSlotItem(Transform parent)
    {
        UiSlotItem uiSlotItem = Instantiate(uiSlotItemPrefab, parent);
        AddSlotItems(uiSlotItem);
        return uiSlotItem;
    }

    public virtual void OnSlotItemBeginDrag(UiSlotItem uiSlotItem)
    {
        RemoveSlotItems(uiSlotItem);
    }

    public virtual void OnSlotItemEndDrag(UiSlotItem uiSlotItem)
    {
        AddSlotItems(uiSlotItem);
    }

    #region HelperFunctions
    private void AddSlotItems(UiSlotItem uiSlotItem)
    {
        print("AddSlotItems");
        uiSlotItems.Add(uiSlotItem);
        uiSlotItem.OnSlotItemBeginDrag += OnSlotItemBeginDrag;
        uiSlotItem.OnSlotItemEndDrag += OnSlotItemEndDrag;
    }

    private void RemoveSlotItems(UiSlotItem uiSlotItem)
    {
        uiSlotItem.OnSlotItemBeginDrag -= OnSlotItemBeginDrag;
        uiSlotItem.OnSlotItemEndDrag -= OnSlotItemEndDrag;
        uiSlotItems.Remove(uiSlotItem);
    }
    #endregion
}